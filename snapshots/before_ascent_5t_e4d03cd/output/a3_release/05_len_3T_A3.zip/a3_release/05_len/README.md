# 혼합 A3 2 · Len·튀잉·카데나 나머지3개 · 16조각

[현재 3T 제작 파일](3T/sheet_01) · [선택 대안 5T](5T/sheet_01)

![3T 배치](3T/sheet_01/preview.png)

![5T 대안 배치](5T/sheet_01/preview.png)

![줄줄이 튀잉 · 실제 조각 연결 참고](../../individual_assets/linked_tuiing_assembly.png)

공통 배경·받침 한 세트에 일반76mm·DOT50mm 캐릭터를 교체합니다. 발 아래 돌기 폭18mm, 삽입깊이3T2.6mm. 중복 받침·시험편 없음. 3T는16조각이며 카데나 나머지3개와 양검 받침을 함께 배치했습니다. 양검 캐릭터·키링은 혼합A3 1에 있습니다. 5T 대안에는 양검·카데나가 없습니다.

![일반 조립 참고](assembly.png)

![일반·DOT 실제 크기 비율과 새 발 돌기](assembly_dot.png)

실물 검증 전입니다. [전체 출력 안내](../README.md)
